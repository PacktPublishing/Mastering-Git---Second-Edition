# Random Number Generator

Generates random integer within the given range.
